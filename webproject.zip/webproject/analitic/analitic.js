const themeSwitchCheckbox = document.getElementById('theme-switch-checkbox');
const assetInput = document.getElementById("assetInput");
const chartContainer = document.getElementById("tradingview_chart");
let chartWidget;

// Проверяем, сохранена ли тема в LocalStorage
let currentTheme = localStorage.getItem('theme');
if (currentTheme) {
  document.documentElement.setAttribute('data-theme', currentTheme);
  themeSwitchCheckbox.checked = currentTheme === 'dark';
}

// Функция обновления графика
function updateChart(symbol) {
  if (chartWidget) {
    // Если виджет уже существует, обновляем символ
    chartWidget.chart().setSymbol(symbol, () => {
      // Обновляем тему графика, если нужно
      if (currentTheme === 'dark') {
        chartWidget.chart().applyOptions({
          "theme": "dark"
        });
      } else {
        chartWidget.chart().applyOptions({
          "theme": "light"
        });
      }
    });
  } else {
    // Если виджет еще не создан, создаем его
    chartWidget = new TradingView.widget({
      "container_id": "tradingview_chart",
      "autosize": true,
      "symbol": symbol,
      "theme": currentTheme === 'dark' ? 'dark' : 'light' // Начальная тема
    });
  }
}

// Инициализируем виджет TradingView
updateChart("BTCUSD"); 

// Привязываем обработчик изменения темы *после* инициализации виджета
themeSwitchCheckbox.addEventListener('change', function() {
  if (this.checked) {
    document.documentElement.setAttribute('data-theme', 'dark');
    localStorage.setItem('theme', 'dark');
    chartWidget.chart().applyOptions({
      "theme": "dark"
    }); 
  } else {
    document.documentElement.setAttribute('data-theme', 'light');
    localStorage.setItem('theme', 'light');
    chartWidget.chart().applyOptions({
      "theme": "light"
    }); 
  }
});

assetInput.addEventListener("change", () => {
  const newSymbol = assetInput.value.toUpperCase();
  updateChart(newSymbol);
});