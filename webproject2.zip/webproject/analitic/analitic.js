const themeSwitchCheckbox = document.getElementById('theme-switch-checkbox');
const assetInput = document.getElementById("assetInput");
const chartContainer = document.getElementById("tradingview_chart");
let chartWidget;

let currentTheme = localStorage.getItem('theme');
if (currentTheme) {
  document.documentElement.setAttribute('data-theme', currentTheme);
  themeSwitchCheckbox.checked = currentTheme === 'dark';
}

function updateChart(symbol) {
  if (chartWidget) {

    chartWidget.chart().setSymbol(symbol, () => {

      if (currentTheme === 'dark') {
        chartWidget.chart().applyOptions({
          "theme": "dark"
        });
      } else {
        chartWidget.chart().applyOptions({
          "theme": "light"
        });
      }
    });
  } else {

    chartWidget = new TradingView.widget({
      "container_id": "tradingview_chart",
      "autosize": true,
      "symbol": symbol,
      "theme": currentTheme === 'dark' ? 'dark' : 'light' 
    });
  }
}

updateChart("BTCUSD"); 

themeSwitchCheckbox.addEventListener('change', function() {
  if (this.checked) {
    document.documentElement.setAttribute('data-theme', 'dark');
    localStorage.setItem('theme', 'dark');
    chartWidget.chart().applyOptions({
      "theme": "dark"
    }); 
  } else {
    document.documentElement.setAttribute('data-theme', 'light');
    localStorage.setItem('theme', 'light');
    chartWidget.chart().applyOptions({
      "theme": "light"
    }); 
  }
});

assetInput.addEventListener("change", () => {
  const newSymbol = assetInput.value.toUpperCase();
  updateChart(newSymbol);
});