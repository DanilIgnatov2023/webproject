const lossPercentTPInput = document.getElementById('lossPercentTP');
const stopLossTPInput = document.getElementById('stopLossTP');
const currentPriceTPInput = document.getElementById('currentPriceTP');
const takeProfitResultSpan = document.getElementById('takeProfitResult');

const tradeTypeSLSelect = document.getElementById('tradeTypeSL');
const investmentAmountSLInput = document.getElementById('investmentAmountSL');
const leverageSLInput = document.getElementById('leverageSL');
const maxLossSLInput = document.getElementById('maxLossSL');
const currentPriceSLInput = document.getElementById('currentPriceSL');
const stopLossResultSpan = document.getElementById('stopLossResult');

const settingsButton = document.querySelector('.settings-button');
const settingsMenu = document.querySelector('.calculator-settings');
const decimalPlacesInput = document.getElementById('decimalPlaces');
const unitsSelect = document.getElementById('units');

let decimalPlaces = 5; 
let units = 'points'; 

function calculateTakeProfit() {
  const lossPercent = parseFloat(lossPercentTPInput.value) / 100;
  const stopLoss = parseFloat(stopLossTPInput.value);
  const currentPrice = parseFloat(currentPriceTPInput.value);

  const profitMultiplier = (lossPercent / (1 - lossPercent)) * 2.5;
  const takeProfit = currentPrice + (profitMultiplier * Math.abs(currentPrice - stopLoss));

  takeProfitResultSpan.textContent = takeProfit.toFixed(decimalPlaces);
}

function calculateStopLoss() {
  const tradeType = tradeTypeSLSelect.value;
  const investmentAmount = parseFloat(investmentAmountSLInput.value);
  const leverage = parseFloat(leverageSLInput.value);
  const maxLoss = parseFloat(maxLossSLInput.value);
  const currentPrice = parseFloat(currentPriceSLInput.value);

  let stopLoss;
  if (tradeType === 'SELL') {
    stopLoss = currentPrice + (maxLoss / (investmentAmount * leverage));
  } else {
    stopLoss = currentPrice - (maxLoss / (investmentAmount * leverage));
  }

  stopLossResultSpan.textContent = stopLoss.toFixed(decimalPlaces);
}

lossPercentTPInput.addEventListener('input', calculateTakeProfit);
stopLossTPInput.addEventListener('input', calculateTakeProfit);
currentPriceTPInput.addEventListener('input', calculateTakeProfit);

tradeTypeSLSelect.addEventListener('change', calculateStopLoss);
investmentAmountSLInput.addEventListener('input', calculateStopLoss);
leverageSLInput.addEventListener('input', calculateStopLoss);
maxLossSLInput.addEventListener('input', calculateStopLoss);
currentPriceSLInput.addEventListener('input', calculateStopLoss);

settingsButton.addEventListener('click', () => {
  settingsMenu.classList.toggle('show');
});

decimalPlacesInput.addEventListener('change', () => {
  decimalPlaces = parseInt(decimalPlacesInput.value);
  calculateTakeProfit(); 
  calculateStopLoss();
});

unitsSelect.addEventListener('change', () => {
  units = unitsSelect.value;
  calculateTakeProfit();
  calculateStopLoss();
});

const themeSwitchCheckbox = document.getElementById('theme-switch-checkbox');

let currentTheme = localStorage.getItem('theme');
if (currentTheme) {
  document.documentElement.setAttribute('data-theme', currentTheme);
  themeSwitchCheckbox.checked = currentTheme === 'dark';
}

themeSwitchCheckbox.addEventListener('change', function() {
  if (this.checked) {
    document.documentElement.setAttribute('data-theme', 'dark');
    localStorage.setItem('theme', 'dark');
  } else {
    document.documentElement.setAttribute('data-theme', 'light');
    localStorage.setItem('theme', 'light');
  }
});